/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package pkg440project;

/**
 *
 * @author Dylan
 */
import java.util.Scanner;
import java.util.Arrays;
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        Scanner auth = new Scanner(System.in);
        String alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        String codedMessage;
        int[] modA = {1,9,21,15,3,19,7,23,11,5,17,25};
        
        
        System.out.println("Welcome Decrypt Keeper! Please input the coded message.");
        codedMessage = auth.nextLine();
        System.out.println(codedMessage);
        
        for (int i = 0; i < codedMessage.length(); i++) 
        {
            String decryptedMessage = "";
            int tempChar = alphabet.indexOf(codedMessage.charAt(i));
            tempChar = tempChar + 27;
            char decryptedChar = alphabet.charAt((tempChar) % 26);
            if(codedMessage.charAt(i) == ' ') 
                {
                 decryptedChar = ' ';
                }
            decryptedMessage = decryptedMessage + decryptedChar;
            System.out.print(decryptedMessage);
            System.out.println();
        }
        
        for (int i = 0; i < 26; i++) 

        {
            String decryptedMessage = "";
            int key = i;
            for (int j = 0; j < codedMessage.length(); j++) 
            {
                int tempChar = alphabet.indexOf(codedMessage.charAt(j));
                if (tempChar - key < 0)
                {
                    tempChar = 26 + tempChar - key;
                }else {
                    tempChar = tempChar - key;
                }
                char decryptedChar = alphabet.charAt((tempChar) % 26);
                 if(codedMessage.charAt(j) ==' ') 
                {
                 decryptedChar = ' ';
                }

                decryptedMessage = decryptedMessage + decryptedChar;
            }
            System.out.println(decryptedMessage);
        }

        for (int i = 0; i < modA.length; i++)
        {
            for (int j = 0; j < 26; j++) 

        {
            String decryptedMessage = "";
            for (int k = 0; k < codedMessage.length(); k++) 
            {
                int tempChar = alphabet.indexOf(codedMessage.charAt(k));
                if ((modA[i]*(tempChar - j)) % 26 < 0)
                {
                        tempChar = 26 +(modA[i]*(tempChar - j) % 26);
                }
                else 
                {
                    tempChar = (modA[i]*(tempChar - j) % 26);
                }
                char decryptedChar = alphabet.charAt((tempChar));
                 if(codedMessage.charAt(k) == ' ') 
                {
                 decryptedChar = ' ';
                }

                decryptedMessage = decryptedMessage + decryptedChar;
            }
            System.out.println(decryptedMessage);
        }
        }
        
        
        
        
    }
        
    
    
}
